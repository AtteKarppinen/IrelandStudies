public class GrandWizard extends Wizard {
    
	// over-riding the method
    public void sayName() {
        System.out.println("Grand wizard " + name);
    }
}