import java.util.ArrayList;

public class Wizard extends Dude {

    //New properties
    ArrayList<String> spells;
	
	//New behaviours
    public void cast(String spell) {
        // cool stuff here
        mp -= 10;
    }
}