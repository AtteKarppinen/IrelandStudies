public class Game {

    public static void main(String[]args){
	
        Dude d1 = new Dude();	
		d1.name = "Jeff Lebowski";
		
		Dude d2 = new Dude();
		d2.name = "Bad Dude";
		d2.punchFace(d1);
		
		System.out.println(d1.name + ": " + d1.hp + " points!");
		
		Wizard w1 = new Wizard();
		w1.name = "Oz";
		
		d2.punchFace(w1);
		System.out.println(w1.name + ": " + w1.hp + " points!");
		
		GrandWizard g1 = new GrandWizard();
		g1.name = "Flash";
        g1.sayName();
        ((Dude)g1).sayName();
		
		g1.punchFace(d2);
		System.out.println(d2.name + ": " + d2.hp + " points!");
		
	}
}