package app.creaturecompendium.DB;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import java.util.List;
import app.creaturecompendium.Models.Heroes;

@Dao
public interface HeroDAO {
    @Insert
    void insertHero(Heroes... hero);

    @Delete
    void deleteHero(Heroes... hero);

    @Update
    void updateHero(Heroes... hero);

    @Query("SELECT * FROM Heroes")
    List<Heroes> getAllHeroes();

    @Query("SELECT * FROM Heroes WHERE castle = :castleIndex")
    List<Heroes> getAllHeroesByCastle(int castleIndex);

    @Query("SELECT * FROM Heroes WHERE id = :id")
    Heroes getHeroWithId(int id);
}
