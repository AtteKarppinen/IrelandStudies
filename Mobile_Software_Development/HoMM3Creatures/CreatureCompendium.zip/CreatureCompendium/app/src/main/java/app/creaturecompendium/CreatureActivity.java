package app.creaturecompendium;

import android.arch.persistence.room.Room;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import app.creaturecompendium.DB.AppDatabase;
import app.creaturecompendium.DB.CreatureDAO;
import app.creaturecompendium.Models.Creatures;

public class CreatureActivity extends AppCompatActivity {

    private CreatureDAO mCreatureDAO;
    private CreatureAdapter mAdapter;
    private ListView mCreatureList;
    private Task mAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creature);

        mCreatureDAO = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "AppDatabase")
                .build()
                .getCreatureDAO();

        //region Add Creatures !ONLY DEVELOPMENT!
//        Example creatures. At this point add .allowMainThreadQueries() to DAO above and uncomment when first time running app
//        try {
//            mCreatureDAO.insertAll(
//                    new Creatures("Goblin", 5, 5, 4, 2, "1-2", 40, 0, "No", 1),
//                    new Creatures("Hobgoblin", 5, 7, 5, 3, "1-2", 50, 0, "No", 1),
//                    new Creatures("Wolf Rider", 10, 6, 7, 5, "2-4", 100, 0, "No", 1),
//                    new Creatures("Wolf Raider", 10, 8, 8, 5, "3-4", 140, 0, "No", 1),
//
//                    new Creatures("Gremlin", 4, 4, 3, 3, "1-2", 30, 0, "No", 2),
//                    new Creatures("Master Gremlin", 4, 5, 4, 4, "1-2", 40, 8, "No", 2),
//                    new Creatures("Stone Gargoyle", 16, 6, 6, 6, "2-3", 130, 0, "Yes", 2),
//                    new Creatures("Obsidian Gargoyle", 16, 9, 7, 7, "2-3", 160, 0, "Yes", 2),
//
//                    new Creatures("Pixie", 3, 7, 2, 2, "1-2", 25, 0, "Yes", 3),
//                    new Creatures("Sprite", 3, 9, 2, 2, "1-3", 30, 0, "Yes", 3),
//                    new Creatures("Air Elemental", 25, 7, 9, 9, "2-8", 250, 0, "No", 3),
//                    new Creatures("Storm Elemental", 25, 8, 9, 9, "2-8", 275, 24, "No", 3),
//
//                    new Creatures("Imp", 4, 5, 2, 3, "1-2", 50, 0, "No", 4),
//                    new Creatures("Familiar", 4, 7, 4, 4, "1-2", 60, 0, "No", 4),
//                    new Creatures("Gog", 13, 4, 6, 4, "2-4", 125, 12, "No", 4),
//                    new Creatures("Magog", 13, 6, 7, 4, "2-4", 175, 24, "No", 4),
//
//                    new Creatures("Skeleton", 6, 4, 5, 4, "1-3", 60, 0, "No", 5),
//                    new Creatures("Skeleton Warrior", 6, 5, 6, 6, "1-3", 70, 0, "No", 5),
//                    new Creatures("Walking Dead", 15, 3, 5, 5, "2-3", 100, 0, "No", 5),
//                    new Creatures("Zombie", 20, 4, 5, 5, "2-3", 125, 0, "No", 5),
//
//                    new Creatures("Centaur", 8, 6, 5, 3, "2-3", 70, 0, "No", 6),
//                    new Creatures("Centaur Captain", 10, 8, 6, 3, "2-3", 90, 0, "No", 6),
//                    new Creatures("Dwarf", 20, 3, 6, 7, "2-4", 120, 0, "No", 6),
//                    new Creatures("Battle Dwarf", 20, 5, 7, 7, "2-4", 150, 0, "No", 6),
//
//                    new Creatures("Pikeman", 10, 3, 4, 4, "1-3", 60, 0, "No", 7),
//                    new Creatures("Haldberdier", 10, 5, 6, 5, "2-3", 75, 0, "No", 7),
//                    new Creatures("Archer", 10, 4, 6, 3, "2-3", 100, 12, "No", 7),
//                    new Creatures("Marksman", 10, 6, 6, 3, "2-3", 150, 24, "No", 7),
//
//                    new Creatures("Troglodyte", 5, 4, 4, 3, "1-3", 50, 0, "No", 8),
//                    new Creatures("Infernal Troglodyte", 6, 5, 5, 4, "1-3", 65, 0, "No", 8),
//                    new Creatures("Harpy", 14, 6, 6, 5, "1-4", 130, 0, "Yes", 8),
//                    new Creatures("Harpy Hag", 14, 9, 6, 6, "1-4", 170, 0, "Yes", 8),
//
//                    new Creatures("Gnoll", 6, 4, 3, 5, "2-3", 50, 0, "No", 9),
//                    new Creatures("Gnoll Marauder", 6, 5, 4, 6, "2-3", 70, 0, "No", 9),
//                    new Creatures("Lizardman", 12, 4, 5, 6, "1-3", 110, 12, "No", 9),
//                    new Creatures("Lizard Warrior", 12, 5, 5, 7, "2-3", 130, 24, "No", 9)
//            );
//        }catch (Exception e) {
//            e.printStackTrace();
//        }
        //endregion

        mCreatureList   = findViewById(R.id.list_creatures);
        mAdapter        = new CreatureAdapter(CreatureActivity.this, 0, new ArrayList<Creatures>());
        mCreatureList.setAdapter(mAdapter);

        loadCreatures();
    }

    private void loadCreatures() {
        mAsyncTask = new Task(mAdapter, mCreatureDAO);
        mAsyncTask.execute();
    }

    class Task extends AsyncTask<Void, Void, Void> {

        private CreatureAdapter creatureAdapter;
        private CreatureDAO creatureDAO;

        Task(CreatureAdapter creatureAdapter, CreatureDAO creatureDAO) {
            this.creatureAdapter = creatureAdapter;
            this.creatureDAO = creatureDAO;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            creatureAdapter.updateData((ArrayList<Creatures>) creatureDAO.getAllCreatures());
            return null;
        }
    }
}
