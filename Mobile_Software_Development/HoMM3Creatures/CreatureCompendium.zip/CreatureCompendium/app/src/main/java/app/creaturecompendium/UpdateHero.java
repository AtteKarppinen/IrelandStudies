package app.creaturecompendium;

import android.arch.persistence.room.Room;
import android.database.sqlite.SQLiteConstraintException;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import app.creaturecompendium.DB.AppDatabase;
import app.creaturecompendium.DB.HeroDAO;
import app.creaturecompendium.Models.Heroes;

public class UpdateHero extends AppCompatActivity {

    private EditText mHeroName, mHeroSpecialty, mHeroSkill;
    private Button mUpdateButton, mDeleteButton;
    private HeroDAO mHeroDAO;
    private Heroes mHero;
    private Spinner mSpinnerClass;
    private ArrayAdapter<String> mSpinnerAdapter;
    private Task mAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_hero);

        // Set spinner and items
        mSpinnerClass = findViewById(R.id.hero_spinner_class_update);
        mSpinnerAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item,
                getResources().getStringArray(R.array.Classes));
        mSpinnerAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        mSpinnerClass.setAdapter(mSpinnerAdapter);

        mHeroDAO = Room.databaseBuilder(UpdateHero.this, AppDatabase.class, "AppDatabase")
                .build()
                .getHeroDAO();

        mHeroName       = findViewById(R.id.hero_edit_name);
        mHeroSpecialty  = findViewById(R.id.hero_edit_specialty);
        mHeroSkill      = findViewById(R.id.hero_edit_skill);
        mUpdateButton   = findViewById(R.id.hero_update_button);
        mDeleteButton   = findViewById(R.id.hero_delete_button);

        mAsyncTask = new Task(mHeroDAO, mHero);
        mAsyncTask.execute();
    }

    private void initializeViews() {

        mHeroName.setText(mHero.getHeroName());
        mSpinnerClass.setSelection(mSpinnerAdapter.getPosition(mHero.getHeroClass()));
        mHeroSpecialty.setText(mHero.getSpecialty());
        mHeroSkill.setText(mHero.getSkill());

        //region Update Button
        mUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name         = mHeroName.getText().toString();
                String heroClass    = mSpinnerClass.getSelectedItem().toString();
                String specialty    = mHeroSpecialty.getText().toString();
                String skill        = mHeroSkill.getText().toString();

                if (name.length() == 0 || heroClass.length() == 0 ||
                        specialty.length() == 0 || skill.length() == 0) {
                    Toast.makeText(UpdateHero.this, "Please make sure all details are correct", Toast.LENGTH_SHORT).show();
                    return;
                }

                mHero.setHeroName(name);
                mHero.setHeroClass(heroClass);
                mHero.setSpecialty(specialty);
                mHero.setSkill(skill);

                mAsyncTask = new Task(mHeroDAO, mHero, "update");
                mAsyncTask.execute();
            }
        });
        //endregion

        //region Delete Button
        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAsyncTask = new Task(mHeroDAO, mHero, "delete");
                mAsyncTask.execute();
            }
        });
        //endregion
    }

    class Task extends AsyncTask<Void, Void, Heroes> {
        private HeroDAO heroDAO;
        private Heroes hero;
        private String operation;

        Task(HeroDAO heroDAO, Heroes hero) {
            this.heroDAO = heroDAO;
            this.hero = hero;
        }

        Task(HeroDAO heroDAO, Heroes hero, String operation) {
            this.heroDAO = heroDAO;
            this.hero = hero;
            this.operation = operation;
        }

        @Override
        protected Heroes doInBackground(Void... voids) {
            hero = heroDAO.getHeroWithId(getIntent().getIntExtra("hero_id", -1));

            if (operation == "update") {
                //Insert to database
                try {
                    mHeroDAO.updateHero(mHero);
                    setResult(RESULT_OK);
                    finish();
                } catch (SQLiteConstraintException e) {
                    Toast.makeText(UpdateHero.this, "A Hero with same name already exists.", Toast.LENGTH_LONG).show();
                }
            }
            else if (operation == "delete") {
                try {
                    mHeroDAO.deleteHero(mHero);
                    setResult(RESULT_OK);
                    finish();
                } catch (SQLiteConstraintException e) {
                    Toast.makeText(UpdateHero.this, "Something went wrong.", Toast.LENGTH_LONG).show();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Heroes result) {
            mHero = hero;

            if (operation == null || operation == "") {
                initializeViews();
            }
        }
    }
}

