package app.creaturecompendium;

import android.arch.persistence.room.Room;
import android.database.sqlite.SQLiteConstraintException;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import app.creaturecompendium.DB.AppDatabase;
import app.creaturecompendium.DB.HeroDAO;
import app.creaturecompendium.Models.Heroes;

public class CreateHero extends AppCompatActivity {

    private EditText mHeroName, mHeroSpecialty, mHeroSkill;
    private HeroDAO mHeroDAO;
    private Button mCreateButton;
    private Spinner mSpinnerClass;
    private ArrayAdapter<String> mSpinnerAdapter;
    private Task mAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_hero);

        // Set spinner and items
        mSpinnerClass = findViewById(R.id.hero_spinner_class);
        mSpinnerAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item,
                getResources().getStringArray(R.array.Classes));
        mSpinnerAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        mSpinnerClass.setAdapter(mSpinnerAdapter);

        mHeroName       = findViewById(R.id.edit_hero_name);
        mHeroSkill      = findViewById(R.id.edit_hero_skill);
        mHeroSpecialty  = findViewById(R.id.edit_hero_specialty);
        mCreateButton   = CreateHero.this.findViewById(R.id.button_create);

        mHeroDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .build()
                .getHeroDAO();

        mCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String heroName         = mHeroName.getText().toString();
                String heroClass        = mSpinnerClass.getSelectedItem().toString();
                String heroSkill        = mHeroSkill.getText().toString();
                String heroSpecialty    = mHeroSpecialty.getText().toString();

                if (heroName.length() == 0 || heroSkill.length() == 0 || heroSpecialty.length() == 0) {
                    Toast.makeText(CreateHero.this, "Enter all details", Toast.LENGTH_SHORT).show();
                    return;
                }

                Heroes hero = new Heroes();
                hero.setCastle(1);
                hero.setHeroName(heroName);
                hero.setHeroClass(heroClass);
                hero.setSkill(heroSkill);
                hero.setSpecialty(heroSpecialty);

                mAsyncTask = new Task(hero);
                mAsyncTask.execute();
            }
        });
    }

    class Task extends AsyncTask<Void, Void, Void> {

        private Heroes hero;

        Task(Heroes hero) {
            this.hero = hero;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                mHeroDAO.insertHero(hero);
                setResult(RESULT_OK);
                finish();
            } catch (SQLiteConstraintException e) {
                Toast.makeText(CreateHero.this, "A Hero with same name already exists.", Toast.LENGTH_LONG).show();
            }
            return null;
        }
    }
}
