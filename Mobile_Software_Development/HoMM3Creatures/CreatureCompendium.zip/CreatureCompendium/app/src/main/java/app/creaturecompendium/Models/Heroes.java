package app.creaturecompendium.Models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

@Entity
//        (foreignKeys = @ForeignKey(
//        entity          = Castles.class,
//        parentColumns   = "id",
//        childColumns    = "castle" ))
public class Heroes {

    @PrimaryKey(autoGenerate = true)
    public int id;

    private String heroName;
    private String heroClass;
    private String specialty;
    private String skill;
    private int castle;

    public int getId() { return id; }

    public void setHeroName(String heroName) { this.heroName = heroName; }
    public String getHeroName() { return heroName; }

    public void setHeroClass(String heroClass) { this.heroClass = heroClass; }
    public String getHeroClass() { return heroClass; }

    public void setSpecialty(String specialty) { this.specialty = specialty; }
    public String getSpecialty() { return specialty; }

    public void setSkill(String skill) { this.skill = skill; }
    public String getSkill() { return skill; }

    public void setCastle(int castle) { this.castle = castle; }
    public int getCastle() { return castle; }
}
