package app.creaturecompendium;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import java.util.ArrayList;

import app.creaturecompendium.DB.AppDatabase;
import app.creaturecompendium.DB.HeroDAO;
import app.creaturecompendium.Models.Heroes;

public class HeroActivity extends AppCompatActivity {

    private RecyclerView mHeroView;
    private HeroAdapter mHeroAdapter;
    private HeroDAO mHeroDAO;
    private FloatingActionButton mAddButton;

    private static final int CREATE_HERO = 1;
    private static final int UPDATE_HERO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hero);

        mHeroDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries()
                .build()
                .getHeroDAO();

        mHeroView = findViewById(R.id.list_heroes);
        mHeroView.setHasFixedSize(true);
        mHeroView.setLayoutManager(new LinearLayoutManager(HeroActivity.this));
        mAddButton = findViewById(R.id.add_hero);

        mHeroAdapter = new HeroAdapter(new ArrayList<Heroes>(), this);

        mHeroAdapter.addActionCallBack(new HeroAdapter.ActionCallback() {
            @Override
            public void onClickListener(Heroes hero) {
                Intent intent = new Intent(HeroActivity.this, UpdateHero.class);
                intent.putExtra("hero_id", hero.getId());
                startActivityForResult(intent, UPDATE_HERO);
            }
        });

        mHeroView.setAdapter(mHeroAdapter);

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HeroActivity.this, CreateHero.class);
                startActivityForResult(intent, CREATE_HERO);
            }
        });
        loadHeroes();
    }

    private void loadHeroes() {
        mHeroAdapter.updateData(mHeroDAO.getAllHeroes());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_HERO && resultCode == RESULT_OK) {
            loadHeroes();
        }
        else if (requestCode == UPDATE_HERO && resultCode == RESULT_OK) {
            loadHeroes();
        }
    }
}
