package app.creaturecompendium.Models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class Castles {

    @PrimaryKey(autoGenerate = true)
    public int id;

    private String castleName;

    public Castles(String castleName) { this.castleName = castleName; }

    // For pre-populating database
    public static Castles[] populateCastleTable() {
        return new Castles[] {
                new Castles("STRONGHOLD"),  // ID = 1
                new Castles("TOWER"),       // ID = 2
                new Castles("CONFLUX"),     // ID = 3
                new Castles("INFERNO"),     // ID = 4
                new Castles("NECROPOLIS"),  // ID = 5
                new Castles("RAMPART"),     // ID = 6
                new Castles("CASTLE"),      // ID = 7
                new Castles("DUNGEON"),     // ID = 8
                new Castles("FORTRESS")     // ID = 9
//                new Castles("NEUTRAL"),
        };
    }

    public String getCastleName() { return castleName; }

    public void setCastleName(String castleName) { this.castleName = castleName; }
}

