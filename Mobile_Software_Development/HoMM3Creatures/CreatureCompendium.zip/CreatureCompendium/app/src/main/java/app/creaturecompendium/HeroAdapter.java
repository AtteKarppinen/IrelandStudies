package app.creaturecompendium;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import app.creaturecompendium.Models.Heroes;

public class HeroAdapter extends RecyclerView.Adapter<HeroAdapter.ViewHolder> {

    //Interface for callbacks
    interface ActionCallback {
        void onClickListener(Heroes hero);
    }

    private List<Heroes> heroes;
    private Context context;
    private ActionCallback mActionCallback;

    public HeroAdapter(List<Heroes> heroes, Context context) {
        this.heroes = heroes;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.hero_row, viewGroup, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        Heroes hero = heroes.get(i);

        viewHolder.mHeroName.setText(hero.getHeroName());
        viewHolder.mHeroClass.setText(hero.getHeroClass());
        viewHolder.mHeroSpecialty.setText(hero.getSpecialty());
        viewHolder.mHeroSkill.setText(hero.getSkill());
    }

    @Override
    public int getItemCount() {
        return heroes.size();
    }

    void updateData(List<Heroes> heroes) {
        this.heroes = heroes;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mHeroName, mHeroClass, mHeroSpecialty, mHeroSkill;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            mHeroName       = itemView.findViewById(R.id.hero_name);
            mHeroClass      = itemView.findViewById(R.id.hero_class);
            mHeroSpecialty  = itemView.findViewById(R.id.hero_specialty);
            mHeroSkill      = itemView.findViewById(R.id.hero_skill);
            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View v) {
            if (mActionCallback != null) {
                mActionCallback.onClickListener(heroes.get(getAdapterPosition()));
            }
        }
    }
    void addActionCallBack(ActionCallback actionCallback) {
        mActionCallback = actionCallback;
    }
}
