package app.creaturecompendium.DB;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import java.util.List;
import app.creaturecompendium.Models.Castles;


@Dao
public interface CastleDAO {

    @Query("SELECT * FROM Castles")
    List<Castles> getAllCastles();

    // For pre-populating database
    @Insert
    void insertAll(Castles... castles);

    // For inserting one castle
    @Insert
    void insertCastle(Castles... castles);
}
