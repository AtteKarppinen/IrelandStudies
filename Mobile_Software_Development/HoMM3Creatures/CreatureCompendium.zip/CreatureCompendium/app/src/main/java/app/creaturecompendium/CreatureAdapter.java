package app.creaturecompendium;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import app.creaturecompendium.Models.Creatures;

public class CreatureAdapter extends ArrayAdapter<Creatures> {

    private CreatureActivity mActivity;
    private ArrayList<Creatures> mCreatureList;
    private static LayoutInflater mInflater = null;

    public CreatureAdapter(CreatureActivity activity, int textViewResourceId, ArrayList<Creatures> creatureList) {

        super(activity, textViewResourceId, creatureList);
        this.mActivity      = activity;
        this.mCreatureList  = creatureList;
        mInflater           = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return mCreatureList.size();
    }

    public Creatures getCreature(Creatures creature) {
        return creature;
    }

    public long getItemId(int position) {
        return position;
    }

    void updateData(ArrayList<Creatures> creatures) {
        this.mCreatureList = creatures;
        notifyDataSetChanged();
    }

    public static class ViewHolder {
        public TextView creature_name, creature_health,
                creature_speed, creature_attack, creature_defense,
                creature_damage, creature_cost, creature_shots, creature_fly;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        final ViewHolder holder;

        try {
            if (convertView == null) {
                view = mInflater.inflate(R.layout.creature_row, null);
                holder = new ViewHolder();

                holder.creature_name    = view.findViewById(R.id.creature_name);
                holder.creature_health  = view.findViewById(R.id.creature_health);
                holder.creature_speed   = view.findViewById(R.id.creature_speed);
                holder.creature_attack  = view.findViewById(R.id.creature_attack);
                holder.creature_defense = view.findViewById(R.id.creature_defense);
                holder.creature_damage  = view.findViewById(R.id.creature_damage);
                holder.creature_cost    = view.findViewById(R.id.creature_cost);
                holder.creature_shots   = view.findViewById(R.id.creature_shots);
                holder.creature_fly     = view.findViewById(R.id.creature_fly);

                view.setTag(holder);
            }
            else {
                holder = (ViewHolder) view.getTag();
            }

            holder.creature_name.setText(mCreatureList.get(position).getCreatureName());
            holder.creature_health.setText(String.valueOf(mCreatureList.get(position).getHealth()));
            holder.creature_speed.setText(String.valueOf(mCreatureList.get(position).getSpeed()));
            holder.creature_attack.setText(String.valueOf(mCreatureList.get(position).getAttack()));
            holder.creature_defense.setText(String.valueOf(mCreatureList.get(position).getDefense()));
            holder.creature_damage.setText(String.valueOf(mCreatureList.get(position).getDamage()));
            holder.creature_cost.setText(String.valueOf(mCreatureList.get(position).getCost()));
            holder.creature_shots.setText(String.valueOf(mCreatureList.get(position).getShots()));
            holder.creature_fly.setText(mCreatureList.get(position).getFly());


        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }
}
