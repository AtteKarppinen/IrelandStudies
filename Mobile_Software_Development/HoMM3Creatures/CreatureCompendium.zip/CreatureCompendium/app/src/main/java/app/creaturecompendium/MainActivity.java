package app.creaturecompendium;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity
{
    //region imgs and themes
    private Integer[] mBackgrounds = {
            R.drawable.background_mainmenu, R.drawable.background_castle,
            R.drawable.background_conflux, R.drawable.background_dungeon,
            R.drawable.background_fortress, R.drawable.background_inferno,
            R.drawable.background_necropolis, R.drawable.background_rampart,
            R.drawable.background_stronghold, R.drawable.background_tower
    };
    private Integer[] mThemeSongs = {
            R.raw.main_menu, R.raw.town_castle,
            R.raw.town_conflux, R.raw. town_dungeon,
            R.raw.town_fortress, R.raw.town_inferno,
            R.raw.town_necropolis, R.raw.town_rampart,
            R.raw.town_stronghold, R.raw.town_tower
    };
    //endregion

    private RelativeLayout mMainLayout;         // Main page layout
    private int mIndex;                         // For looping through backgrounds/songs
    private MediaPlayer mPlayer;


    @SuppressLint("ClickableViewAccessibility") // Something about visually impaired people
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMainLayout = findViewById(R.id.layout_main);
        mIndex      = 1;     // Start with 1 so background changes from main menu image

        // Make background changeable by double tapping the screen
        mMainLayout.setOnTouchListener(new View.OnTouchListener() {
            private GestureDetector mGestureDetector = new GestureDetector(MainActivity.this,
                    new GestureDetector.SimpleOnGestureListener() {

                        @Override
                        public boolean onDoubleTap(MotionEvent event) {
                            changeBackground();
                            return false;
                        }
                    });

            // This will pass data of the click to mGestureDetector
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mGestureDetector.onTouchEvent(event);
                return true;
            }
        });
    }

    private void changeBackground() {
        mMainLayout.setBackgroundResource(mBackgrounds[mIndex]);

        try {
            mPlayer.pause();     // Can't be started straight away
            mPlayer = MediaPlayer.create(MainActivity.this, mThemeSongs[mIndex]);
            mPlayer.setLooping(true);
            mPlayer.start();
        }
        catch (IllegalStateException e) {
            // Thrown if something is wrong with media player current state
            e.printStackTrace();
        }

        if (mIndex >= mBackgrounds.length - 1)  mIndex = 0;
        else                                    mIndex += 1;
    }

    public void showCreatures(View view) {
        Intent intent = new Intent(MainActivity.this, CreatureActivity.class);
        startActivity(intent);
    }

    public void showHeroes(View view) {
        Intent intent = new Intent(MainActivity.this, HeroActivity.class);
        startActivity(intent);
    }

    public void visitWebsite(View view) {
        String website = "https://sites.google.com/site/heroes3hd/";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(website));

        // If there is an app that can handle the intent, result is not null
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
        else {
            Toast.makeText(this, "No required apps found", Toast.LENGTH_LONG).show();
        }
    }

    public void exitApplication(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Exit the Application")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finishAndRemoveTask();
                    }
                })
                .setNegativeButton("Go Back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    //region Lifecycles
    @Override
    protected void onPause() {
        super.onPause();
        Log.wtf("lifecycle","onPause");

        mPlayer.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.wtf("lifecycle","onResume");

        // Media player should be null only when app gets started the first time
        if (mPlayer == null)
            mPlayer = MediaPlayer.create(MainActivity.this, R.raw.main_menu);
        mPlayer.setLooping(true);
        mPlayer.start();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.wtf("lifecycle","onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.wtf("lifecycle","onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.wtf("lifecycle","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release resources
        if (mPlayer != null) mPlayer.release();
        Log.wtf("lifecycle","onDestroy");
    }
//endregion
}
