package app.creaturecompendium.DB;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import app.creaturecompendium.Models.Creatures;


@Dao
public interface CreatureDAO {

    @Query("SELECT * FROM Creatures")
    List<Creatures> getAllCreatures();

    @Query("SELECT * FROM Creatures WHERE castle = :castleIndex")
    List<Creatures> getAllCreaturesByCastle(int castleIndex);

    // For pre-populating database
    @Insert
    void insertAll(Creatures... creatures);
}
