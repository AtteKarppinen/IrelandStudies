Online shop application. 

This project was part of the Web Development & Deployment module at Dublin Institute of Technology (Semester 1, 2018).

Project can be run using XAMPP-localhost
https://www.apachefriends.org/index.html

No other setup is needed, but internet connection is necessary to make libraries work (project uses CDNs).

Project members:

Jussi Hieta     https://github.com/J-Hieta

Atte Karppinen  https://github.com/AtteKarppinen
