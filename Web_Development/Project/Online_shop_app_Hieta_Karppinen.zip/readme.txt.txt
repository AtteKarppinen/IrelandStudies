To deploy the application the user needs to have localhost service (XAMPP) installed and configured appropriately with Apache and mysql services. 

MySQL database must be created in http://localhost/phpmyadmin/ (can be opened from XAMPP control panel, MySQL Admin). 
SQL-code for the database creation is provided inside the project folder (Online shop application) as db.sql. 

Project folder must be copied to a folder that is defined in Apache configuration file (httpd.conf) as document root.

When this is done, the user simply needs to open the application folder in localhost.
