INSERT INTO tbleducation (eduSchool, eduStartYear, eduEndYear) VALUES('Elementary',2000 ,2003);
INSERT INTO tbleducation (eduSchool, eduStartYear, eduEndYear) VALUES('High School',2004 ,2008);
INSERT INTO tbleducation (eduSchool, eduStartYear, eduEndYear) VALUES('College',2010 ,2013);